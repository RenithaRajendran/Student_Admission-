from flask import Blueprint, render_template, redirect, request, flash, url_for
from .forms import ApplicationForm
from .models import Application
from . import db
import os
from werkzeug.utils import secure_filename
from .pdf_utils import generate_admission_letter
import logging
logging.basicConfig(level=logging.DEBUG)


bp = Blueprint('main', __name__)

@bp.route('/')
def index():
    return redirect('/apply')

@bp.route('/apply', methods=['GET', 'POST'])
def apply():
    form = ApplicationForm()
    if form.validate_on_submit():
        doc = form.document.data
        filename = secure_filename(doc.filename)
        doc.save(os.path.join('app/static/uploads', filename))
        new_app = Application(
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            email=form.email.data,
            degree=form.degree.data,
            document=filename
        )
        db.session.add(new_app)
        db.session.commit()
        flash('Application submitted successfully!', 'success')
        return redirect(url_for('main.apply'))
    return render_template('apply.html', form=form)

@bp.route('/admin')
def admin():
    applications = Application.query.all()
    return render_template('admin.html', applications=applications)

@bp.route('/approve/<int:id>')
def approve(id):
    app = Application.query.get_or_404(id)
    app.status = "Approved"
    db.session.commit()
    generate_admission_letter(app)
    flash('Approved & PDF generated!')
    return redirect('/admin')
