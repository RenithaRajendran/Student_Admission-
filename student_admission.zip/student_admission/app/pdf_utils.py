# app/pdf_utils.py
from reportlab.pdfgen import canvas

def generate_admission_letter(app):
    path = f'app/static/letters/admission_{app.id}.pdf'
    c = canvas.Canvas(path)
    c.drawString(100, 750, f"Admission Letter for {app.first_name} {app.last_name}")
    c.drawString(100, 730, f"Degree: {app.degree}")
    c.drawString(100, 710, f"Status: {app.status}")
    c.save()
