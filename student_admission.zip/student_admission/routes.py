from flask import Blueprint, render_template, redirect, url_for, request, flash
from . import db
from .models import Application
from .forms import ApplicationForm
from flask_login import login_required
from .pdf_utils import generate_admission_letter
from werkzeug.utils import secure_filename
import os

bp = Blueprint('app', __name__)

@bp.route('/apply', methods=['GET', 'POST'])
def apply():
    form = ApplicationForm()
    if form.validate_on_submit():
        filename = None
        if form.document.data:
            filename = secure_filename(form.document.data.filename)
            form.document.data.save(os.path.join('app/static/uploads', filename))
        
        application = Application(
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            email=form.email.data,
            degree=form.degree.data,
            document=filename
        )
        db.session.add(application)
        db.session.commit()
        flash('Application submitted successfully!', 'success')
        return redirect(url_for('app.apply'))
    return render_template('apply.html', form=form)

@bp.route('/admin')
@login_required
def admin():
    applications = Application.query.all()
    return render_template('admin.html', applications=applications)

@bp.route('/approve/<int:application_id>')
@login_required
def approve(application_id):
    application = Application.query.get_or_404(application_id)
    application.status = 'Approved'
    db.session.commit()
    
    # Generate the admission letter
    generate_admission_letter(application)
    
    flash('Application approved successfully!', 'success')
    return redirect(url_for('app.admin'))

@bp.route('/reject/<int:application_id>')
@login_required
def reject(application_id):
    application = Application.query.get_or_404(application_id)
    application.status = 'Rejected'
    db.session.commit()
    flash('Application rejected.', 'danger')
    return redirect(url_for('app.admin'))
